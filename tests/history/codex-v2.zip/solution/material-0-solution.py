import sys

def solve():
    values = list(map(int, sys.stdin.buffer.read().split()))
    n = values[0]
    coins = sorted(values[1:1+n])
    kept = []
    for coin in coins:
        if not any(coin % previous == 0 for previous in kept):
            kept.append(coin)
    print(len(kept))

if __name__ == '__main__':
    solve()
